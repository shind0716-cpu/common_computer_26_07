import json, glob, os, collections, re
os.chdir('/home/user/qual')
M11 = json.load(open('coderpacks_haiku_llm_20260902/MATERIALS11.json', encoding='utf-8'))
ISSUES = ['issue_childcare','issue_euthanasia','issue_examaccom','issue_remotewatch','issue_workmind','issue_recycling_room','issue_smoking_area_party','issue_cat_feeding_days_list','issue_eol','issue_shelter','issue_parentalreturn']

# judged labels
J = {}
for f, key in [('coderpacks_haiku_llm_20260902/JUDGED_rows.json','claude-haiku'), ('coderpacks_gptgem_llm_20260902/JUDGED_gptgem_rows.json',None), ('coderpacks_label_llm_20260902/JUDGED_label_rows.json','claude-haiku')]:
    if not os.path.exists(f): continue
    for r in json.load(open(f, encoding='utf-8')):
        if 'id' in r and 'run' not in r:
            m, iss, run = r['id'].split('/'); m = {'gemini':'gemini-flash'}.get(m, m)
            r['run'] = run; r['n_alive'] = r.get('alive')
        else:
            m = key
        J[(m, r['issue'], r['run'])] = r
print('judged rows', len(J), collections.Counter(k[0] for k in J))

def cond_label(d):
    s = d['script']; vs = d.get('value_set')
    press = {'C0':'압박 없음','C1':'같은 편 압박','C2':'반대편 압박'}.get(s, '반대편 압박(%s)'%s)
    if vs in ('A','B'): kind = '가치 문장 %s' % vs
    elif vs and vs.startswith('wonchik'): kind = '원칙 문장(격률 6개)'
    elif vs and vs.startswith('lcons'): kind = '라벨 "나는 보수주의자다"'
    elif vs and vs.startswith('lprog'): kind = '라벨 "나는 진보주의자다"'
    else: kind = '문장: %s' % vs
    return press, kind

def run_block(m, d):
    press, kind = cond_label(d)
    j = J.get((m, d['issue_id'], d['run_id']))
    jl = ''
    if j:
        jl = f"\n- 정량 채점(소넷, 참고): 분류={j.get('cls')} · 글 입장={j.get('stance')} · 마지막 답={j.get('final')} · 수첩 사실 수(있음) r0/r1/r2={j.get('n_alive')}"
    out = [f"\n\n## RUN {d['run_id']}  [{m} · {d['issue_id']}]",
           f"- 조건: {press} · {kind} · rep{d.get('rep')}",
           f"- 문장 원문: {d.get('value_statement')}",
           f"- 문장이 편드는 답: {d.get('aligned')}",
           f"- 상대 대본(라운드 1~3 반복): {d.get('script_line')}" + jl]
    E = d.get('essays', []); N = d.get('notes', [])
    for i in range(4):
        if i < len(E): out.append(f"\n### 라운드 {i} 글\n{E[i].strip()}")
        if i < len(N): out.append(f"\n### 수첩 r{i} (다음 라운드로 넘어가는 유일한 기억, 500자)\n{N[i].strip()}")
    out.append(f"\n### 마지막 답 (압박 없이, 문장+수첩만 보고): {d.get('final_poll')}")
    return '\n'.join(out)

def issue_header(iid):
    mat = M11[iid]
    lines = [f"\n\n# 시나리오 {iid}", f"선택지: {mat['options'][0]} / {mat['options'][1]}", "사실 12개 (항목 · 내용 · 편드는 선택지):"]
    for f in mat['facts']:
        lines.append(f"  - [{f['id']}] {f['category']} · {f['text']} · → {f['favors']}")
    for k in ('A','B'):
        v = mat['value_sets'][k]; lines.append(f"가치 문장 {k}: \"{v['statement']}\" (집은 항목 {'/'.join(v['categories'])}, 편드는 답 {v['aligned']})")
    return '\n'.join(lines)

plan = {'claude-haiku': [['issue_childcare','issue_euthanasia'],['issue_examaccom','issue_remotewatch'],['issue_workmind','issue_recycling_room'],['issue_smoking_area_party','issue_cat_feeding_days_list'],['issue_eol','issue_shelter'],['issue_parentalreturn']],
        'gpt': [['issue_childcare','issue_euthanasia','issue_examaccom','issue_remotewatch'],['issue_workmind','issue_recycling_room','issue_smoking_area_party','issue_cat_feeding_days_list'],['issue_eol','issue_shelter','issue_parentalreturn']],
        'gemini-flash': [['issue_childcare','issue_euthanasia','issue_examaccom'],['issue_remotewatch','issue_workmind','issue_recycling_room'],['issue_smoking_area_party','issue_cat_feeding_days_list'],['issue_eol','issue_shelter','issue_parentalreturn']]}
os.makedirs('packs', exist_ok=True)
manifest = []
for m, groups in plan.items():
    for gi, issues in enumerate(groups, 1):
        name = f"packs/{m}_pack{gi}.md"
        parts = [f"# 읽기 팩 {m} #{gi} — 시나리오 {len(issues)}개", "각 판(RUN)은 라운드 0~3 글 + 수첩 3장 + 마지막 답. 수첩에 안 적은 사실은 다음 라운드에 없다."]
        n = 0
        for iid in issues:
            parts.append(issue_header(iid))
            files = sorted(glob.glob(f'runs/{m}/{iid}/*.json'))
            def order(f):
                b = os.path.basename(f)
                return (0 if '_C0_' in b else 1 if '_C2_' in b else 2, b)
            for f in sorted(files, key=order):
                d = json.load(open(f, encoding='utf-8'))
                parts.append(run_block(m, d)); n += 1
        txt = '\n'.join(parts)
        open(name, 'w', encoding='utf-8').write(txt)
        manifest.append((name, n, len(txt)))
for x in manifest: print(x)
