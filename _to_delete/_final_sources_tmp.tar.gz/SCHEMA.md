# SCHEMA — 파일 계약 v0.2 (원본: 노션 「스키마 — 파일 계약 5종 (현행 v0.2)」)

> **길잡이 (2026-07-30 민옥 추가 — 본문 무수정, 요한 님 확인 요망)**
> 위 제목은 v0.2지만 **이 문서는 v0.3까지 반영돼 있다.** append-only 원칙에 따라 제목을
> 고치지 않고 아래에 덧붙였기 때문이다(§ "v0.3 — 발화 입력 기록 추가" 이하).
> **앞부분만 읽고 v0.2 로 판단하지 말 것** — 실측 사고: 2026-07-30 새 세션이 제목만 보고
> v0.2 기준으로 작업을 시작했다.
> 현행에 포함된 v0.3 추가분: `prompt_assembly` 이벤트 · `ledger_inject.injected_text` ·
> `note_update` 이벤트 · `prompt_assembly.note` 슬롯 · `prompt_assembly.slots.window`.
>
> **(2026-07-31 요한 확인 — 이 길잡이를 정본으로 접수.** 갱신 의무는 아래 「버전 규칙」 참조.
> 위 목록은 작성 시점에 이미 `run_meta`(§4‴)가 빠져 있었다 — 길잡이도 본문과 같은 이유로
> 낡는다는 실례다. 누락분과 이후 추가분을 여기 잇는다: `run_meta` 이벤트(§4‴) ·
> `settings.reasoning`·`settings.deviations`(§4⁗) · `judge{}` 문면 명확화(§5′).**)**
>
> (2026-08-10 요한 추가 — 「버전 규칙」의 갱신 의무 이행) `issue.question`(§1′).

공통: UTF-8, snake_case. 모든 파일에 schema_ver/created_by/created_at.
경로는 modules/paths.py로만 유도. 검사는 modules/validate.py.

## 1. issues/{issue_id}.json
issue_id, source(company_json|paper|synthetic), source_meta{url, fetched_at, usage_approved}, title, body

## 2. facts/facts_{issue_id}.json
extractor{model, temperature, prompt_ver}
facts[]: fact_id, text, tags[condition|exception|counter_evidence|stance_support], critical(bool),
         prior{score 0~1|null, probe_model, probe_prompt_ver, probed_at}
주의: 라운드별 상태(언급/반박/무시)는 여기 없음 — 동적 정보라 judgment에서 관리

## 3. assignments/assignment_{issue_id}.json
seed(필수), agents[]: agent_id, perspective, stance(pro|con), assigned_fact_ids[]

## 4. debates/debate_{issue_id}_{run_id}.jsonl  (한 줄 = 이벤트 하나)
utterance: run_id, ledger_mode(off|v0|v1|v2|a1), round, agent_id, model, temperature,
           prompt_ver, prompt_hash(sha256), response_text(원문, 요약 금지), ts
ledger_inject: round, injected_fact_ids[], reason(v0_all_missing|v1_ignored_only), ts
gate_check: draft_text, missing_fact_ids[], verdict(pass|rollback), rollback_count(최대 1), ts

## 5. judgments/judgment_{issue_id}_{run_id}.json
judge{model: sonnet, temperature: 0, n_votes: 3, aggregation: majority, prompt_ver}
stage_type: "round"(실험 트랙) | "summary_layer"(관찰 트랙)
stages[]: stage, facts[]: fact_id, status(unmentioned|mentioned|accepted|refuted|ignored),
          votes[](3표 원본 보존 — 불일치율 = judge 신뢰도 지표), agents_mentioning[]
recall_probe[](선택, A4용): agent_id, recalled_fact_ids[], extra_lines
summary: far_by_stage[], far_system, far_agent_mean(관찰 트랙은 null), far_critical

## 버전 규칙
수정 시 이 파일과 노션 양쪽에 새 버전 절을 아래로 추가. 구현 중 문제 제기는 노션 패키지 A 항목으로.

(2026-07-31 요한 추가) 새 버전 절을 아래에 추가하는 사람은 **머리말 길잡이의 추가분 목록에도
한 줄 더한다.** 길잡이는 요약이 아니라 색인이다 — 본문을 대체하지 않으므로 재요약 금지에
걸리지 않는다. 근거: 목록이 갱신되지 않아 작성 3일 만에 `run_meta`가 빠진 채로 남아 있었다.

## FAR 정의 — 스프린트 잠정 확정 (2026-07-22, 민옥/리더)
동범.md·judge.py가 남긴 열린 질문("FAR 수식 방향, 미확정 시 미니 H1 판정 불성립")을 미니 스프린트 한정으로 잠정 확정한다. **기업 확인(패키지 A Q: FAR 수식 방향) 회신 시 이 절과 judge.py의 SURVIVING/far()를 교체한다.**

- **방향**: 손실↑ = FAR↑ (FAR = 소실 팩트 수 / 대상 팩트 수). 값이 클수록 사실 보존이 나쁨.
- **소실 판정**: status ∉ SURVIVING. 스프린트 SURVIVING = {mentioned, accepted}. 즉 unmentioned·refuted·ignored = 소실.
  - 근거: judge v0는 프롬프트상 mentioned/unmentioned 2종만 산출(동범.md 설계노트). 2종 체계에서 소실 = unmentioned. accepted/refuted/ignored 자리는 v1 상태추적에서 채운다.
- **critical 한정**: far_critical = 위 식을 facts[].critical=true 팩트로만 집계.
- **미니 H1 판정 기준**: 대조군(ledger off) 실호출 1회에서 far_by_stage[]의 far_system·far_critical이 산출되면 H1(현상 재현) 성립으로 본다. 절대 수치 신뢰는 유보(judge 노이즈, W2 검증 과제).
- **미니 H2 판정 기준**: 동일 이슈·시드로 ledger on/off 쌍 비교 시, on의 far_critical이 off보다 낮으면(단조일 필요 없음) v0 유효 신호. 판정은 far_by_stage 곡선(단계별 분해)까지 함께 본다.
- Ledger v0의 '소실=재주입 대상' 정의는 이 SURVIVING과 **동일 소스**를 쓴다(modules/ledger.MISSING = status ∉ SURVIVING). judge와 ledger가 같은 잣대를 쓰도록 강제.

### ⚠ 통합 전 확인 필요 (2026-07-22)
리포의 judgment_issue_esa_dryrun.json(구버전, v1 픽스처 교체 전 산출)과 현재 judge.py 출력 구조가 다름:
- 드라이런: facts[].votes = [{agent_id, votes:[bool×3]}], summary에 far_system_critical/far_agent_mean_critical
- judge.py: facts[].votes = [{status, agents_mentioning, reason}×3], summary에 far_critical
ledger는 stages[].facts[].{fact_id,status} 두 필드만 의존하므로 양쪽 모두에서 동작하나, 수 밤 통합 시 judge 실호출 산출물의 최종 구조를 동범과 확정할 것.

## judgment 구조 확정 (2026-07-22, 민옥/리더 — 동범 승인 7/22 보드)
7/21 리더 확정 체제(스키마는 리더 측이 확정, 구현상 문제 제기는 보드 패키지 A 항목)에 따라 「⚠ 통합 전 확인 필요」의 구조 드리프트를 확정한다. **근거**: docs/P2_INPUT_CONTRACT.md(요한, 7/22) + 코드 확인 3건(D1·B·C, 보드 7/22 민옥 측 답변) + **담당자 승인(동범, 7/22 보드 회신 — "이의 없음" + 코드 사실 보강)**. 코드 수정 0줄 — 현행 구현을 정본으로 문서화하는 확정이다.

1. **정본 = 현행 judge.py 출력 구조.**
   - stages[].facts[]: `{fact_id, status, votes[{status, agents_mentioning, reason} × n_votes], agents_mentioning[]}`
   - summary: `{far_by_stage[], far_system, far_agent_mean, far_critical}`
   - 구 드라이런(judgment_issue_esa_dryrun.json)은 레거시 강건성 픽스처로 보존(동범 7/22 결정), 현행 구조 정본은 judgment_issue_esa_dryrun2.json — 신규 소비자는 dryrun2를 참조한다.
2. **stage 키는 모든 stage 레코드에 필수, 정렬 가능한 정수** (P2 질문 A). 실험 트랙 기점 = 0-기반 [0..N], round 0(초기 발화) 포함.
3. **각 stage의 facts[]는 추적 대상 전 팩트의 완전 스냅샷** (P2 질문 C) — 델타/변경분 기록 금지. "레코드 부재 = 소실"(P2 결정 2)의 전제 조건으로 명문화. 오프라인·루프-내 판정 모두 충족(동범 코드 사실 보강).
4. **관찰 트랙(stage_type=summary_layer)의 stage 시간 단조성은 loader가 보장** (P2 질문 B) — 전이 지표(P2) 적용 가능 여부는 호출 측 계약이다.
5. **judge v0 산출 status는 mentioned/unmentioned 2종** (judge-v0.2-binary, 저자 evaluate_fact 규칙 계승) — lost_by_status의 refuted/ignored 칸은 judge v1(5종 상태 실산출) 전까지 구조적으로 0이며, 결과 보고 시 이 주석을 의무로 단다 (P2 질문 E).
6. **SURVIVING 최종값(P2 질문 D)은 본 확정과 별개 트랙** — 기업 회신 시 「FAR 정의」절과 judge.SURVIVING/far()만 교체한다(기존 강제 유지). 교체 절차는 docs/proposals/FAR_SWAP_PLAN.md 참조.

구현상 문제 제기는 보드 패키지 A 항목 아래로(append-only).

## v0.3 — 발화 입력 기록 추가 (2026-07-28, 요한 확정 — 규약 7 소관 확정, 보드 회신 게시)

추가 2건, 기존 이벤트·필드 변경·삭제 0 (append 호환 — 구 로그는 prompt_assembly 부재 시 종전 재구성 방식으로 유효).

### 4′. debates jsonl 이벤트 추가
- **`prompt_assembly`** (새 이벤트): run_id, round, agent_id, template, prompt_ver, setting_key,
  slots{assigned_fact_ids[], others[]:{round,agent_id}, previous:{round,agent_id}, inject:{round}|null},
  prompt_hash(sha256 — 같은 (round,agent_id)의 utterance.prompt_hash와 동일값 = 결합 키), ts
- **`ledger_inject.injected_text`** (필드 추가): 프롬프트에 붙은 재주입 블록 원문 전문 (요약 금지).
- 검증 계약: 레시피 재조립 텍스트의 sha256 == prompt_hash. validate `--deep` 옵션에서 검사(기본 검사는 구조만).

### 경계 조항 (개정 1 — 정제 시나리오 과적합 방지·드리프트 강건성)
1. **복원 불가 텍스트 전문 저장(일반 조항)**: 저장된 사건들로부터 결정론적으로 재조립할 수 없는
   신규 텍스트가 프롬프트에 들어가는 채널은 그 원문을 해당 이벤트에 전문 저장한다 (injected_text는 첫 사례).
2. **노출 어휘 한정**: 파생 뷰의 노출은 직접 노출(원문/원문 발화 참조 포함, 조립 참조에서 결정론 유도)만
   정의. 매개 노출(파생 텍스트 경유)은 예약 개념 — 해당 통신 구조 도입 시 별도 정의 없이 적용 금지.
3. **template 등록제 + 창 정책**: 정본 등록값 discussion_initial|discussion_continue. 새 조건은 새
   template명 등록(스키마 본체 불변), 등록 시 창 정책(rolling|cumulative) 명시.

노출표 (agent, fact, round, 경로 assigned|neighbor|ledger)는 저장하지 않고 사건에서 유도한다(사건 원장 1급, 지표는 뷰). 상세·근거: docs/proposals/SCHEMA_v0.3_PROMPT_ASSEMBLY.md (부록 A 포함).

### 4″. 개인 수첩 슬롯 (2026-07-29, 요한 확정 — 규약 7 소관 확정)

민옥 측 「실험 설정 사전 v0」(2026-07-29)의 개인 수첩 신설분. 추가 2건, 기존 이벤트·필드 변경·삭제 0
(구 로그는 note 슬롯 부재 시 `--deep`이 종전대로 통과).

- **`note_update`** (새 이벤트): run_id, ts, agent_id, round(이 갱신이 일어난 라운드),
  note_text(원문 전량 — 요약·절단 금지), origin(model|intervention), source(utterance|dedicated).
  경계 조항 1(복원 불가 텍스트 전문 저장)의 **두 번째 사례**. 수첩의 "현재 값"은 저장하지 않는다
  (사건 1급·상태는 뷰) — 이벤트 부재가 곧 미갱신이다.
- **`prompt_assembly.note`** (슬롯 추가): {agent_id, source_round} | null. `source_round`는 "직전
  라운드"로 계산하지 않고 **실제 사용한 판본의 라운드를 그대로** 적는다(round 0 및 갱신 생략 라운드
  때문). null이면 슬롯 블록 **자체를 생략**한다(빈 문자열 삽입과 해시가 다르다). 참조 대상
  `note_update`가 없으면 `--deep`은 실패로 처리한다.
- **A-2 발동 (경계 조항 2의 매개 노출 첫 사례)**: 수첩 경유 도달은 **매개 노출**로 분류하며 직접
  노출과 합산하지 않는다. 수첩이 켜진 조건(`memory: note`)에서 **P3 층1 지표(전달 폭 B·TSR·획득
  hazard)는 산출하지 않는다.** 정량 정의는 판정 없이 성립하는 방법이 나올 때까지 예약을 유지한다.
  층1은 수첩 없는 조건에서 종전대로 유효하다.
- **설정 좌표 분리**: `memory: none|note` 와 `note_budget`(기본 500)은 별개 칸이다. `window`(창
  정책, 경계 조항 3)와 `memory`는 직교하며 수첩을 창 정책 값으로 넣지 않는다.

상세·근거: docs/proposals/SCHEMA_v0.3_NOTE_SLOT.md (사전고정 커밋 a5af1bb — 고정 이후 변경은 append 전용).

### 4‴. run_meta 이벤트 — 산출물이 자기 조건을 안다 (2026-07-29, 요한 확정 — 규약 7 소관)

추가 1건(새 이벤트), 기존 이벤트·필드 변경·삭제 0. 구 로그는 run_meta 부재 시 종전대로 유효하다.

**왜**: 조건 정의는 `configs/*.yaml`에 있는데 **산출물이 그 config를 가리키지 않았다.** 로그에는
`ledger_mode` 한 칸만 실리고 seed·rounds·structure·stance는 실리지 않아, "이 run이 어떤 조건이었나"가
사람 기억과 run_id 문자열에만 있었다(민옥 「실험 설정 사전 v0」 §1 증상 ①). 조건 어휘가 확정된 지금
그 어휘를 로그에 싣는다.

- **`run_meta`** (새 이벤트, debate jsonl **첫 줄**): run_id, ts, issue_id,
  `condition`(사람용 슬러그 — 설정 사전 §3, config에 없으면 null),
  `config_ref{name, sha256}`(조건 정의 파일의 이름과 내용 지문),
  `settings{...}`(설정 사전 8축의 실제 값 — 아래).
- **`settings` = 설정 사전 8축 좌표**: `window`(1 받는 말 범위) · `memory`(2 기억) ·
  `rounds`(3) · `structure`(4 연결 모양) · `stance`(5 입장 — assignment에서 유도) ·
  `persona`(6 성격) · `overlap_k`·`assignment_mode`(7 정보 나누기 — assignment에서 유도) ·
  `ledger_mode`(8 장부). 부수: `seed` · `agents` · `debate_model` · `debate_temperature`.
- **`config_ref.sha256`이 하는 일**: 조건 파일이 나중에 수정되면 해시가 달라져 **옛 run과 새 run이
  같은 조건이 아님이 드러난다.** prompt_hash가 프롬프트에 한 것과 같은 수법 — 통제를 사람 기억이
  아니라 지문으로 고정한다.
- 검증 계약: `validate`는 run_meta가 있으면 구조를 검사하고, 없으면 통과시킨다(구 로그 호환).
  값의 의미(예: config와 실제 실행의 일치)는 검사하지 않는다 — 얕은 계약 검사 원칙 유지.

주의: `settings`는 **엔진이 실제로 실행한 값**을 적는다(config 원문 복사가 아니다). 미구현 축은
엔진의 현행 동작을 그대로 적는다(예: 창은 롤링만 구현 → `window: "rolling"`, 수첩 미연결 →
`memory: "none"`). 축이 구현되면 그 자리를 실제 값으로 채운다.

### 4⁗. ⑨ 추론 모드 축 + 편차 기록 (2026-07-31, 요한 확정 — 규약 7 소관)

`settings` 안 필드 추가 2건. 기존 이벤트·필드 변경·삭제 0. 제안 주체는 민옥 측(7/30 저녁 보고 ③).
**위 §4‴의 "설정 사전 8축"은 이 절로 9축이 된다** — append-only 원칙에 따라 그 줄을 고치지 않고
여기 적는다(설정 사전 쪽 개정은 민옥 소관, 어휘 통일 제안은 보드 7/31 요한 회신).

- **`settings.reasoning`** (`default|off|on`) — 이 run이 **요청한** 추론 모드. `default`는
  "파라미터 미전송(모델 기본값)"이며 **"끔"과 다른 값이다.** 둘을 뭉치면 나중에 "그때 껐던 건가
  안 정한 건가"를 사람 기억에 묻게 된다.
- **`settings.deviations`** (문자열 배열) — 이 run에서 **실제로 일어난** 파라미터 편차.
  요청 좌표와 전송값이 갈린 사실을 적는다. 프로세스 전역 목록에서 이 run 몫만 자른다.

경계 조항:

1. **두 필드는 짝이다.** `reasoning`은 요청, `deviations`는 그 요청이 실제로 어떻게 나갔나.
   함께 있어야 **"켰다고 적혔는데 추론 없이 돈 run"**이 드러난다. `settings` 원칙("실제 실행한
   값")의 예외가 아니라, 한 칸으로는 표현할 수 없던 것을 두 칸으로 쪼갠 것이다.
2. **`run_meta`는 `deviations` 한 칸에 한해 실행 중 재기록된다.** 편차는 첫 호출을 해봐야
   드러나는데 `run_meta`는 로그 첫 줄이라 실행 전에 나간다. `flush()`가 파일을 통째로 다시
   쓰므로 체크포인트마다 채워진다. **이 예외는 이 필드에만 적용되며, 다른 이벤트·필드의 사후
   수정은 종전대로 금지다.**
3. **중단된 run의 `deviations`는 그 시점까지의 누계다.** 완주 로그와 같은 의미로 읽지 말 것.

append 호환: 구 로그는 두 필드 부재 시 종전대로 유효하다. **부재는 "모름"이지 "default·편차
없음"이 아니다** — 집계에서 빈 배열과 같이 세지 말 것.

검증 계약: `validate`는 구조만 본다(얕은 계약 검사 원칙 유지). 편차 문자열의 의미는 검사하지 않는다.

후속(지금 막지 않음): 사건 원장 1급 원칙만 보면 편차는 발생 시점에 별도 이벤트(`run_deviation`)로
append하는 편이 맞다. 지금 구조로도 기록은 남으므로 실험을 막지 않고, 편차가 여러 번·다른 시점에
나기 시작하면 그때 옮기는 것을 검토한다.

상세·근거: 보드 소통 스레드 2026-07-31 요한 회신 + 결정 로그 「스키마 v0.3 — `run_meta.settings.
reasoning`·`deviations` 2필드 추가」.

### 5′. `judge{}` 는 실제 전송값을 적는다 (2026-07-31, 요한 — 문면 명확화, 계약 변경 없음)

§5 의 `judge{}` 필드 **의미는 바뀌지 않는다.** 처음부터 "이 판정에 실제로 쓰인 사양"이었고,
이 문서가 `prompt_hash`·`config_ref.sha256`·`run_meta.settings`에서 세운 원칙("기록은 실제를
가리킨다")과 같은 자리다. cfg 값을 적는 것은 그 원칙의 다른 해석이 아니라 위반이다.

> `judge{}`는 **실제 판정 호출에 전송된 값**을 적는다. config 값과 다르면 전송값을 적는다.

발동 계기(2026-07-31 실측, API 호출 0회): 두 판정 경로가 모두 `temperature=0`을 하드코딩해
config를 읽지 않는데(`_online_vote`·`_llm_vote`), 산출물은 `int(cfg["judge_temperature"])`를
적는다. `int()` 절삭 때문에 **config에도 없고 전송값도 아닌 값**이 적힐 수 있다(config 1.2 →
기록 1). 0~1 구간에서는 절삭 결과가 우연히 0과 같아 맞아 보이므로, 한 번 확인해보는 것이
반례가 되지 못한다. 현재 리포의 config는 전부 0이고 기존 judgment 4건도 전부 0이라 **과거
수치는 영향받지 않는다** — 수리해도 옛 값이 변하지 않는다.

수리는 `modules/judge.py` 담당자(동범) 소관이며 이 문면은 스키마 변경이 아니다.

### 1′. `issue.question` 등재 (2026-08-10, 요한 확정 — 규약 7 소관)

`issues/{issue_id}.json` 에 **선택 필드 1개 추가.** 기존 필드 변경·삭제 0. 구 issue 문서는
이 필드 부재 시 종전대로 유효하다(§1 의 필수 키는 그대로).

- **`question`** (문자열 | 부재): 이 이슈로 토론할 **예/아니오 질문**. 발화·판정 프롬프트의
  `<===question===>` 슬롯에 들어가는 문자열이다.

**왜 지금 등재하는가** — 이 필드는 **이미 쓰이고 있는데 계약에만 없었다.**
`debate_engine.run()` 이 `issue_doc.get("question") or issue_doc["title"]` 로 읽고(발화),
`validate.replay_context()` 가 같은 규칙으로 재조립하며(검증), 저자 파이프라인은
`dataset[index]['question']` 을 **1급 필드로 전제**한다(`discussion.py`·`facts_select`·
`evaluate_stance`). 규약 1 이 SCHEMA 를 "모듈 간 약속의 전부"라 부르는데 그 밖에 있었다.

**폴백은 유지하되 계약에 명시한다** — 부재 시 `title` 을 쓴다. 다만 이 폴백은 **조용히
발동한다**: 2026-08-10 실측으로 `data/issues/issue_esa.json` 에 `question` 이 없어 모든 ESA
판의 프롬프트에 제목이 그대로 실렸고, 그 제목은 `"룸메이트 ESA 개 무단 반입 신고 딜레마
(스프린트 정본 v1)"` 라 **리포 버전 태그가 프롬프트로 새어 들어갔다.** 같은 이슈의 파일럿
사본(`experiments/mini_h2_pilot/data`)에는 `question` 이 주입돼 있어 **두 뿌리가 다른 조건으로
돌고 있었다** — 계약에 없으니 아무도 그 차이를 검사하지 않았다.

경계 조항:

1. **폴백 발동은 기록에 드러나야 한다.** `question` 부재로 `title` 을 쓴 run 은 그 사실을
   알 수 있어야 한다(수단은 구현 소관 — 경고 출력이든 `run_meta` 든). 부재 자체는 허용하나
   **"조용히"는 허용하지 않는다.** 이 절이 생긴 계기가 그것이다.
2. **`title` 은 질문이 아니다.** 폴백은 편의이지 설계가 아니다. 새로 적재하는 이슈는
   `question` 을 채운다.
3. **부재는 "모름"이다** — `title` 과 같다는 뜻이 아니다(§4⁗ 의 `reasoning` 부재 처리와 같은
   원칙). 집계에서 폴백 run 과 명시 run 을 같이 세지 말 것.

검증 계약: `validate` 는 **필수 키에 넣지 않는다**(구 문서 호환). 있으면 문자열인지만 본다 —
얕은 계약 검사 원칙 유지. 값이 실제로 질문 형태인지는 검사하지 않는다.

발동 계기: 논문 재현 트랙 데이터(`ethics_issues.json` 710건)가 `question` 을 1급으로 갖고
들어왔고, 적재하려면 계약에 자리가 있어야 했다. 상세: `docs/proposals/PAPER_REPRO_HANDOFF.md`.
